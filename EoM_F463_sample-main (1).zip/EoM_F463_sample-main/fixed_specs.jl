t = 1.6
wb = 2.8
hg = 0.5
mass = 1800
Ix = 800
Iy = 2000
Iz = 2200
drive = "RearWheelDrive"
farea = 3.5
cod = 0.35

mu = 40
kt = 150000